#pragma once
#include<string.h>
#include<iostream>
using namespace std;
class Cake
{
private:
	string name;
public:
	Cake(string name);
	string getName();
};
