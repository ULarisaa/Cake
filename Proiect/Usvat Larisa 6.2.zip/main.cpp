//Usvat Larisa 6.2 an 2
#include<iostream>
#include<fstream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include"CommandPanel.h"

using namespace std;

int main()
{
	string order_name, ans;
	int order_quantity;
	CommandPanel *order=new CommandPanel();
	do {
		cout << "Do you want to order? [Y/N]" << endl;
		cout << "Answer: ";
		cin >> ans;
		if (ans == "N")
		{
			exit(0);
		}
		else if (ans == "Y")
		{
			cout << "Here's our menu: " << endl;
			order->showProducts();
			cout << "Here's the list of the cakes that are available in the store: " << endl;
			order->showProductsInCarousel();
			cout << "Please introduce the name of the cake" << endl << "Answer: ";
			cin >> order_name;
			cout << "Please enter the quantity"<<endl<<"Answer: ";
			cin >> order_quantity;
			if (order_quantity > 1)
			{
					order->selectProduct(order_name, order_quantity);
			}
			else
			{
				order->selectProduct(order_name);
			}
		}
		else
			cout << "Optiune gresita!"<<endl;
		cout << endl;
	} while (ans != "N");
	return 0;
}